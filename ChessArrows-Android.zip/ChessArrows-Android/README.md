# Chess Arrows (studio) per Android

La tua estensione, impacchettata in un'app Android: apre chess.com dentro l'app e disegna le frecce di Stockfish 19 (WASM, locale) come sul PC.

## Ambito (volutamente limitato)
Funziona **solo** su:
- partite contro i bot: `chess.com/play/computer`
- analisi: `chess.com/analysis`
- problemi: `chess.com/puzzles`

Non funziona in partite online contro altre persone né su `/game`. Il controllo è doppio: lo script nella pagina e, in `MainActivity.java`, il ponte Java che guarda l'URL reale del WebView e rifiuta ogni richiesta al motore fuori da quei percorsi (`ALLOWED_PATHS`).
Il blocco titolati del tuo script è rimasto com'era.

## Come ottenere l'APK

### A) Android Studio (sul PC)
1. Installa Android Studio, poi *File > Open* e scegli questa cartella.
2. Aspetta la sincronizzazione Gradle (scarica da solo tutto il necessario).
3. *Build > Build Bundle(s) / APK(s) > Build APK(s)*.
4. L'APK è in `app/build/outputs/apk/debug/app-debug.apk`.

### B) Senza installare nulla (GitHub)
1. Crea un repository su GitHub e carica tutto il contenuto di questa cartella (compresa `.github`).
2. Scheda *Actions* > *Build APK* > *Run workflow*.
3. A fine lavoro scarichi `ChessArrows-apk` dagli *Artifacts*.

### Installazione sul telefono
Copia `app-debug.apk` sul telefono, aprilo e consenti l'installazione da fonti sconosciute quando richiesto.

## Uso
- Si apre su `chess.com/play/computer`. Accedi al tuo account normalmente e naviga come sul sito.
- Il pulsante tondo **♞** (in basso a sinistra) accende e spegne frecce e pannello (al posto di Alt+A).
- Nel pannello: **Partite / Problemi / 960** come prima. **▾ Riduci** lo rimpicciolisce. Si trascina dall'intestazione col dito.
- **✎ Disegna frecce**: attivalo, poi trascina da una casella all'altra per avere valutazione e perdita di cp di una mossa (al posto del tasto destro). Un tocco senza trascinare cancella le etichette.
- Pizzica per ingrandire la pagina: l'app usa il "sito desktop" di chess.com.

## Se qualcosa non va
- **Nessuna freccia / pannello "In attesa della scacchiera"**: chess.com ha cambiato qualcosa nel layout. In `MainActivity.java` metti `DESKTOP_UA = null` per provare il layout mobile, oppure aggiorna i selettori in `app/src/main/assets/csa.js` (stessi del tuo `content.js`).
- **Il pannello non risponde mai (valutazione ferma su "–")**: il motore non è partito. Controlla che in `app/src/main/assets/engine/` ci siano `stockfish-19-lite-single.js` e `.wasm`.
- Parametri del motore: oggetto `MODES` in `csa.js` (`multipv`, `movetime`).

## Struttura
- `app/src/main/assets/csa.js` : il tuo `content.js` adattato (ponte nativo, tocco, localStorage, ambito ristretto)
- `app/src/main/assets/engine/engine.js` : il tuo `offscreen.js` adattato (stessa logica UCI)
- `app/src/main/java/app/chessarrows/MainActivity.java` : WebView di chess.com + WebView nascosto del motore + ponte

Stockfish è GPLv3 (licenza in `app/src/main/assets/engine/`).
