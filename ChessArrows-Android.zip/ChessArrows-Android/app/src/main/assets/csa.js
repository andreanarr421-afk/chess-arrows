(() => {
    "use strict";
    if (window.__csaLoaded) return;
    window.__csaLoaded = true;
    const COLORS = ["#2ecc71", "#f1c40f", "#4aa3ff"]; // 1ª, 2ª, 3ª mossa
    const MODES = {
        normal: { multipv: 3, movetime: 120, chess960: false, stats: true },
        puzzle: { multipv: 1, movetime: 700, chess960: false, stats: false },
        chess960: { multipv: 3, movetime: 120, chess960: true, stats: true },
    };
    const STD = { kf: 4, kr: 7, qr: 0 }; // colonne di re e torri nella posizione iniziale standard
    const blank = () => ({ n: 0, top1: 0, top3: 0, cpl: 0, acc: 0, inv: 0 });
    const fresh = () => ({ w: blank(), b: blank() });

    let mode = "normal", enabled = true, port = null, svg = null, awaiting = null, rightStart = null;
    const marks = new Map();       // frecce disegnate a mano (tasto destro) con la loro valutazione
    let lastInfo = null;             // posizione corrente letta dalla scacchiera
    let prev = null, current = null; // ultime posizioni analizzate {fen, turn, lines, grid}
    let stats = fresh(), verdict = { w: null, b: null };
    let rights = null, home = null; // diritti di arrocco (monotoni: una volta persi non tornano) e colonne di re/torri
    const done = new Set();

    // ---------- Guardia di ambito ----------
    // chess.com è una single-page app: se dall'analisi si passa a una partita online senza ricaricare, lo script resta in memoria.
    // Per questo l'ambito viene ricontrollato di continuo: fuori da bot, analisi e problemi tutto si spegne, contro chiunque.
    const ALLOWED = [/^\/play\/computer(\/|$)/, /^\/analysis(\/|$)/, /^\/puzzles(\/|$)/];
    let blocked = false;
    const allowedHere = () => ALLOWED.some((re) => re.test(location.pathname));
    // Blocco titolati: se accanto alla scacchiera compare un titolo (GM, IM, FM, CM, NM, WGM, WIM, WFM, WCM, WNM)
    // l'estensione si blocca e resta bloccata fino al ricaricamento della pagina. È un livello in più, a prova di errore:
    // scatta anche con bot "celebrità" titolati o in analisi di una partita contro un titolato.
    const TITLES = /^(GM|IM|FM|CM|NM|WGM|WIM|WFM|WCM|WNM)$/;
    const TITLE_SEL = '[class*="user-title"], [class*="chess-title"], [data-test-element*="title"], .cc-user-title-component';
    let titleLock = false;
    const titledHere = () => Array.from(document.querySelectorAll(TITLE_SEL)).some((el) => {
        if (host.contains(el)) return false;
        return TITLES.test((el.textContent || "").trim().toUpperCase());
    });
    function checkScope() {
        if (!titleLock && titledHere()) titleLock = true;
        const ok = allowedHere() && !titleLock;
        if (ok === !blocked) return ok;
        blocked = !ok;
        if (blocked) { if (svg) svg.innerHTML = ""; prev = current = lastInfo = null; awaiting = null; marks.clear(); }
        else lastInfo = null;
        renderHud();
        if (ok) schedule();
        return ok;
    }


    // ---------- Connessione con il motore ----------
    function ensurePort() {
        if (port) return port;
        window.__csaResult = (m) => onResult(m);
        port = { postMessage: (m) => { try { CSAEngine.toEngine(JSON.stringify(m)); } catch (_) { } } };
        port.postMessage({ type: "config", ...MODES[mode] });
        return port;
    }
    function request(fen) { awaiting = fen; ensurePort().postMessage({ fen }); }
    function requestMove(fen, move) { ensurePort().postMessage({ fen, move }); }

    // ---------- Lettura della scacchiera ----------
    const getBoard = () => document.querySelector("wc-chess-board, chess-board");
    const sq = (el) => { const m = /square-(\d)(\d)/.exec(el.className); return m ? { f: +m[1] - 1, r: +m[2] - 1 } : null; };
    const name = (s) => String.fromCharCode(97 + s.f) + (s.r + 1);
    const fromName = (t) => ({ f: t.charCodeAt(0) - 97, r: +t[1] - 1 });
    const isWhite = (p) => p === p.toUpperCase();

    function readBoard(board) {
        const grid = Array.from({ length: 8 }, () => Array(8).fill(null));
        board.querySelectorAll(".piece").forEach((p) => {
            const t = /\b([wb])([pnbrqk])\b/.exec(p.className), s = sq(p);
            if (t && s) grid[s.r][s.f] = t[1] === "w" ? t[2].toUpperCase() : t[2];
        });
        // Ultima mossa dalle caselle evidenziate: la "partenza" è vuota, l'"arrivo" ha il pezzo
        let from = null, to = null, lastMoverWhite = null;
        board.querySelectorAll(".highlight").forEach((h) => {
            const s = sq(h); if (!s) return;
            const piece = grid[s.r][s.f];
            if (piece) { to = s; lastMoverWhite = isWhite(piece); } else from = s;
        });
        const flipped = board.classList.contains("flipped");
        const turn = lastMoverWhite === null ? (mode === "puzzle" ? (flipped ? "b" : "w") : "w") : lastMoverWhite ? "b" : "w";
        const rows = [];
        for (let r = 7; r >= 0; r--) {
            let row = "", empty = 0;
            for (let f = 0; f < 8; f++) {
                const p = grid[r][f];
                if (!p) empty++; else { if (empty) row += empty; empty = 0; row += p; }
            }
            rows.push(row + (empty || ""));
        }
        return { grid, placement: rows.join("/"), turn, flipped, from, to, move: from && to ? name(from) + name(to) : null };
    }

    // ---------- Arrocco, en passant, Chess960 ----------
    function isInitialSetup(g) { // posizione di partenza (standard o Fischer random): pedoni in 2ª/7ª, specchio sulle traverse di fondo
        for (let f = 0; f < 8; f++) {
            const w = g[0][f];
            if (!w || w === "P" || !isWhite(w) || g[7][f] !== w.toLowerCase() || g[1][f] !== "P" || g[6][f] !== "p") return false;
            for (let r = 2; r <= 5; r++) if (g[r][f]) return false;
        }
        return true;
    }
    function infer960(g) { // colonne di re e torri più esterne sulla traversa di fondo
        let rank = g[0].includes("K") ? 0 : g[7].includes("k") ? 7 : -1;
        if (rank < 0) return null;
        const K = rank === 0 ? "K" : "k", R = rank === 0 ? "R" : "r", kf = g[rank].indexOf(K);
        let qr = -1, kr = -1;
        for (let f = 0; f < kf; f++) if (g[rank][f] === R) { qr = f; break; }
        for (let f = 7; f > kf; f--) if (g[rank][f] === R) { kr = f; break; }
        return qr < 0 || kr < 0 ? null : { kf, qr, kr };
    }
    function getHome(g) {
        if (mode !== "chess960") return STD;
        return home || (home = infer960(g));
    }
    function inferRights(g, h) {
        if (!h) return { K: false, Q: false, k: false, q: false };
        return {
            K: g[0][h.kf] === "K" && g[0][h.kr] === "R", Q: g[0][h.kf] === "K" && g[0][h.qr] === "R",
            k: g[7][h.kf] === "k" && g[7][h.kr] === "r", q: g[7][h.kf] === "k" && g[7][h.qr] === "r",
        };
    }
    function updateRights(g, h) { // intersezione: se re o torre si sono mossi, il diritto è perso per sempre
        const base = rights || { K: true, Q: true, k: true, q: true }, inf = inferRights(g, h);
        rights = { K: base.K && inf.K, Q: base.Q && inf.Q, k: base.k && inf.k, q: base.q && inf.q };
    }
    function castleField(h) {
        let c = "";
        if (mode === "chess960" && h) {
            const L = (f) => String.fromCharCode(97 + f);
            if (rights.K) c += L(h.kr).toUpperCase(); if (rights.Q) c += L(h.qr).toUpperCase();
            if (rights.k) c += L(h.kr); if (rights.q) c += L(h.qr);
        } else {
            if (rights.K) c += "K"; if (rights.Q) c += "Q"; if (rights.k) c += "k"; if (rights.q) c += "q";
        }
        return c || "-";
    }
    function buildFen(info, h) {
        let ep = "-";
        if (info.from && info.to) {
            const pc = info.grid[info.to.r][info.to.f];
            if (pc && pc.toLowerCase() === "p" && info.from.f === info.to.f && Math.abs(info.to.r - info.from.r) === 2)
                ep = name({ f: info.to.f, r: (info.to.r + info.from.r) / 2 });
        }
        return `${info.placement} ${info.turn} ${castleField(h)} ${ep} 0 1`;
    }
    // In Chess960 il motore indica l'arrocco come "re x torre": per il disegno lo converto nella casella di arrivo del re
    function dispSquares(uci, grid) {
        let from = uci.slice(0, 2), to = uci.slice(2, 4);
        if (mode === "chess960") {
            const a = fromName(from), b = fromName(to), p = grid[a.r][a.f], q = grid[b.r][b.f];
            if (p && q && p.toLowerCase() === "k" && q.toLowerCase() === "r" && isWhite(p) === isWhite(q))
                to = String.fromCharCode(97 + (b.f > a.f ? 6 : 2)) + to[1];
        }
        return [from, to];
    }
    function engineMove(a, b, grid) { // mossa disegnata a mano -> notazione del motore
        let uci = name(a) + name(b);
        const p = grid[a.r][a.f];
        if (mode === "chess960" && p && p.toLowerCase() === "k" && home) {
            const R = isWhite(p) ? "R" : "r";
            if (b.r === a.r && b.f === 6 && grid[a.r][home.kr] === R) uci = name(a) + name({ f: home.kr, r: a.r });
            else if (b.r === a.r && b.f === 2 && grid[a.r][home.qr] === R) uci = name(a) + name({ f: home.qr, r: a.r });
        }
        if ((p === "P" && b.r === 7) || (p === "p" && b.r === 0)) uci += "q";
        return uci;
    }

    // ---------- Valutazioni ----------
    const toCp = (l) => (l.mate != null ? (l.mate > 0 ? 1000 : -1000) : Math.max(-1000, Math.min(1000, l.cp)));
    const winPct = (cp) => 50 + 50 * (2 / (1 + Math.exp(-0.00368208 * cp)) - 1); // formula di Lichess
    const whiteCp = (l, turn) => (turn === "w" ? 1 : -1) * toCp(l);
    function fmtEval(l, turn) {
        const k = turn === "w" ? 1 : -1;
        if (l.mate != null) return ((l.mate * k) >= 0 ? "+" : "−") + "M" + Math.abs(l.mate);
        const v = (k * l.cp) / 100;
        return (v >= 0 ? "+" : "−") + Math.abs(v).toFixed(2);
    }
    const classify = (cpl) =>
        cpl <= 10 ? ["Ottima", "#2ecc71"] : cpl <= 40 ? ["Buona", "#8bd17c"] :
            cpl <= 90 ? ["Imprecisione", "#f1c40f"] : cpl <= 200 ? ["Errore", "#f08a3c"] : ["Svarione", "#ee5252"];

    function scoreMove(p, mv, newLines) {
        const same = (l) => l.move.slice(0, 4) === mv || dispSquares(l.move, p.grid).join("") === mv;
        const best = p.lines[0], found = p.lines.find(same);
        const top1 = same(best);
        const top3 = p.lines.slice(0, 3).some(same);
        const playedCp = found ? toCp(found) : -toCp(newLines[0]);
        const cpl = top1 ? 0 : Math.min(1000, Math.max(0, toCp(best) - playedCp));
        const acc = top1 ? 100 : Math.max(0, Math.min(100, 103.1668 * Math.exp(-0.04354 * (winPct(toCp(best)) - winPct(playedCp))) - 3.1669));
        const s = stats[p.turn];
        s.n++; s.top1 += top1; s.top3 += top3; s.cpl += cpl; s.acc += acc; s.inv += 1 / Math.max(acc, 1);
        verdict[p.turn] = { cpl, top1, mv };
    }

    const myColor = () => (lastInfo && lastInfo.flipped ? "b" : "w");

    // ---------- Frecce ----------
    function ensureSvg(board) {
        if (svg && svg.isConnected) return svg;
        svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute("viewBox", "0 0 800 800");
        Object.assign(svg.style, { position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none", zIndex: 20 });
        board.appendChild(svg);
        return svg;
    }
    function center(flipped, s2) {
        const f = s2.charCodeAt(0) - 97, r = +s2[1] - 1;
        return { x: ((flipped ? 7 - f : f) + 0.5) * 100, y: ((flipped ? r : 7 - r) + 0.5) * 100 };
    }
    function draw() {
        const board = getBoard(); if (!board) return;
        const s = ensureSvg(board); s.innerHTML = "";
        if (!enabled || !current) return;
        if (mode === "puzzle" && current.turn !== myColor()) return; // nei problemi suggerisco solo quando tocca a te
        const flipped = board.classList.contains("flipped");
        const shown = current.lines.slice(0, MODES[mode].multipv), best = current.lines[0], labels = [];
        const NS = "http://www.w3.org/2000/svg";
        shown.map((l, i) => ({ l, i })).reverse().forEach(({ l, i }) => { // la migliore per ultima, sopra le altre
            const [f2, t2] = dispSquares(l.move, current.grid);
            const a = center(flipped, f2), b = center(flipped, t2);
            const len = Math.hypot(b.x - a.x, b.y - a.y) || 1, ux = (b.x - a.x) / len, uy = (b.y - a.y) / len;
            const px = -uy, py = ux, hw = i === 0 ? 11 : 8, hh = 28, hl = 40;
            const sx = a.x + ux * 12, sy = a.y + uy * 12, ex = b.x - ux * hl, ey = b.y - uy * hl;
            const pts = [[sx + px * hw, sy + py * hw], [ex + px * hw, ey + py * hw], [ex + px * hh, ey + py * hh], [b.x - ux * 4, b.y - uy * 4],
            [ex - px * hh, ey - py * hh], [ex - px * hw, ey - py * hw], [sx - px * hw, sy - py * hw]];
            const poly = document.createElementNS(NS, "polygon");
            poly.setAttribute("points", pts.map((p) => p.map((v) => v.toFixed(1)).join(",")).join(" "));
            poly.setAttribute("fill", COLORS[i]);
            poly.setAttribute("stroke", "rgba(0,0,0,.5)");
            poly.setAttribute("stroke-width", "3");
            poly.setAttribute("stroke-linejoin", "round");
            poly.setAttribute("opacity", i === 0 ? ".9" : ".72");
            s.appendChild(poly);
            labels.push({ i, l, x: a.x + (b.x - a.x) * 0.62, y: a.y + (b.y - a.y) * 0.62 });
        });
        const placed = [];
        labels.sort((p, q) => p.i - q.i).forEach((t) => {
            const loss = Math.max(0, toCp(best) - toCp(t.l));
            pill(s, placed, t.x, t.y, fmtEval(t.l, current.turn), t.i === 0 ? "migliore" : "−" + loss + " cp", COLORS[t.i], t.i === 0 ? "#2ecc71" : "#ff9c9c");
        });
        // frecce disegnate a mano: valutazione e perdita di cp della mossa indicata
        marks.forEach((mk) => {
            const t = center(flipped, dispSquares(mk.uci, current.grid)[1]);
            let l1, l2, c2 = "#ff9c9c";
            if (mk.pending) { l1 = "…"; l2 = "analisi"; c2 = "#8b97a5"; }
            else if (!mk.line) { l1 = "✕"; l2 = "non legale"; c2 = "#8b97a5"; }
            else {
                const loss = Math.max(0, toCp(best) - toCp(mk.line));
                l1 = fmtEval(mk.line, current.turn); l2 = loss === 0 ? "migliore" : "−" + loss + " cp"; c2 = loss === 0 ? "#2ecc71" : "#ff9c9c";
            }
            pill(s, placed, t.x, t.y - 62, l1, l2, "#c084fc", c2);
        });
    }
    function pill(s, placed, x, y, l1, l2, border, c2) {
        for (let k = 0; k < 6 && placed.some((p) => Math.abs(p.x - x) < 96 && Math.abs(p.y - y) < 46); k++) y += 48;
        x = Math.max(48, Math.min(752, x)); y = Math.max(24, Math.min(776, y));
        placed.push({ x, y });
        const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
        g.setAttribute("font-family", "system-ui,Segoe UI,Roboto,sans-serif");
        g.setAttribute("text-anchor", "middle");
        g.innerHTML =
            `<rect x="${x - 46}" y="${y - 21}" width="92" height="42" rx="10" fill="rgba(16,20,26,.9)" stroke="${border}" stroke-width="2.5"/>` +
            `<text x="${x}" y="${y - 3}" font-size="19" font-weight="700" fill="#fff">${l1}</text>` +
            `<text x="${x}" y="${y + 15}" font-size="15" font-weight="600" fill="${c2}">${l2}</text>`;
        s.appendChild(g);
    }

    // ---------- Pannello ----------
    const host = document.createElement("div");
    Object.assign(host.style, { position: "fixed", right: "16px", bottom: "16px", zIndex: 2147483647 });
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>
    :host{all:initial}
    .card{width:272px;background:rgba(18,22,28,.94);color:#e8edf2;border:1px solid #2a3441;border-radius:14px;font:13px/1.4 system-ui,Segoe UI,Roboto,sans-serif;box-shadow:0 8px 28px rgba(0,0,0,.45);overflow:hidden;user-select:none}
    .hd{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;cursor:move;background:#1d2530;font-weight:600}
    .ev{font-size:20px;font-variant-numeric:tabular-nums}
    .modes{display:flex;gap:4px;padding:8px 14px 4px}
    .modes button{flex:1;background:#232d3a;color:#aab6c3;border:1px solid #2f3b4b;border-radius:8px;padding:5px 0;font:600 12px system-ui,sans-serif;cursor:pointer}
    .modes button.on{background:#2f6fed;border-color:#2f6fed;color:#fff}
    .bar{height:6px;background:#0c0f13;margin:6px 14px 2px}.bar i{display:block;height:100%;background:#e8edf2;border-radius:3px;transition:width .25s}
    .bd{padding:6px 14px 12px}.sec{color:#8b97a5;font-size:11px;text-transform:uppercase;letter-spacing:.05em;margin:10px 0 4px}
    .mv{display:flex;align-items:center;gap:8px;padding:2px 0;font-variant-numeric:tabular-nums}
    .mv b{width:9px;height:9px;border-radius:50%;flex:none}.mv span:nth-child(2){flex:1;font-weight:600}.mv em{font-style:normal;color:#8b97a5;font-size:12px}
    table{width:100%;border-collapse:collapse;font-variant-numeric:tabular-nums}th{font-weight:600;color:#8b97a5;font-size:11px;text-align:right;padding-bottom:3px}
    td{padding:2px 0;text-align:right}td:first-child,th:first-child{text-align:left;color:#8b97a5}
    .ls{margin-top:8px;font-size:12px;color:#c9d2dc}.ls b{font-weight:700}.big{font-size:22px;font-weight:700;margin:4px 0;font-variant-numeric:tabular-nums}
    .acc{display:flex;gap:8px}.acc div{flex:1;background:#1d2530;border-radius:10px;padding:6px 10px;text-align:center}.acc small{display:block;color:#8b97a5;font-size:11px}.acc b{font-size:20px;font-variant-numeric:tabular-nums}
    .tools{display:flex;gap:4px;padding:4px 14px 2px}.tools button{flex:1;background:#232d3a;color:#aab6c3;border:1px solid #2f3b4b;border-radius:8px;padding:6px 0;font:600 12px system-ui,sans-serif}
    .tools button.on{background:#7c3aed;border-color:#7c3aed;color:#fff}
    .collapsed .bd,.collapsed .bar,.collapsed .modes{display:none}
  </style><div class="card" id="c"><div class="hd" id="h"><span>♞ Chess Arrows</span><span class="ev" id="ev">–</span></div>
  <div class="modes" id="modes"><button data-m="normal">Partite</button><button data-m="puzzle">Problemi</button><button data-m="chess960">960</button></div>
  <div class="tools"><button id="tdraw">✎ Disegna frecce</button><button id="tcol">▾ Riduci</button></div>
  <div class="bar"><i id="bar" style="width:50%"></i></div><div class="bd" id="bd"></div></div>`;
    document.documentElement.appendChild(host);
    const $ = (id) => root.getElementById(id);

    // ---------- Touch: pannello trascinabile, scala per schermi piccoli, pulsante flottante ----------
    let dragged = false;
    const fab = document.createElement("div");
    fab.textContent = "♞";
    Object.assign(fab.style, { position: "fixed", left: "10px", bottom: "10px", width: "40px", height: "40px", borderRadius: "50%", background: "#1d2530", color: "#fff", font: "22px/36px system-ui,sans-serif", textAlign: "center", zIndex: 2147483647, boxShadow: "0 2px 10px rgba(0,0,0,.5)", border: "2px solid #2f6fed", userSelect: "none", display: "none", boxSizing: "border-box" });
    fab.addEventListener("click", () => toggleEnabled());
    document.documentElement.appendChild(fab);
    const hudK = () => Math.min(3, Math.max(1, innerWidth / (screen.width || innerWidth)));
    function layoutHud() {
        const k = hudK();
        fab.style.transform = "scale(" + k + ")"; fab.style.transformOrigin = "bottom left";
        if (dragged) return;
        Object.assign(host.style, { right: 16 * k + "px", bottom: 16 * k + "px", transform: "scale(" + k + ")", transformOrigin: "bottom right" });
    }
    addEventListener("resize", layoutHud);
    layoutHud();
    (() => {
        let dx = 0, dy = 0, drag = false;
        const start = (cx, cy) => { drag = true; const r = host.getBoundingClientRect(); dx = cx - r.left; dy = cy - r.top; };
        const move = (cx, cy) => {
            if (!drag) return; dragged = true;
            Object.assign(host.style, { left: cx - dx + "px", top: cy - dy + "px", right: "auto", bottom: "auto", transformOrigin: "top left" });
        };
        $("h").addEventListener("mousedown", (e) => { start(e.clientX, e.clientY); e.preventDefault(); });
        addEventListener("mousemove", (e) => move(e.clientX, e.clientY));
        addEventListener("mouseup", () => (drag = false));
        $("h").addEventListener("touchstart", (e) => { const t = e.touches[0]; start(t.clientX, t.clientY); }, { passive: true });
        addEventListener("touchmove", (e) => { if (!drag) return; const t = e.touches[0]; move(t.clientX, t.clientY); e.preventDefault(); }, { passive: false });
        addEventListener("touchend", () => (drag = false));
        $("h").addEventListener("dblclick", () => $("c").classList.toggle("collapsed"));
        $("tcol").addEventListener("click", () => {
            const c = $("c").classList.toggle("collapsed");
            $("tcol").textContent = c ? "▴ Espandi" : "▾ Riduci";
        });
    })();
    $("modes").addEventListener("click", (e) => { const b = e.target.closest("button"); if (b && b.dataset.m !== mode) applyMode(b.dataset.m, true); });
    const refreshModes = () => root.querySelectorAll(".modes button").forEach((b) => b.classList.toggle("on", b.dataset.m === mode));

    function applyMode(m, save) {
        mode = m;
        if (save) { try { localStorage.setItem("csa_mode", m); } catch (_) { } }
        home = null; rights = null; stats = fresh(); verdict = { w: null, b: null };
        prev = current = lastInfo = null; done.clear(); marks.clear();
        if (svg) svg.innerHTML = "";
        if (port) port.postMessage({ type: "config", ...MODES[m] });
        refreshModes(); renderHud(); schedule();
    }

    const pct = (a, n) => (n ? Math.round((100 * a) / n) + "%" : "–");
    function renderHud() {
        fab.style.display = allowedHere() && !titleLock ? "" : "none";
        fab.style.opacity = enabled ? "1" : ".5";
        if (titleLock) { // avviso fisso: niente frecce né analisi finché non ricarichi la pagina
            host.style.display = "";
            $("c").classList.add("collapsed");
            $("ev").textContent = "⛔";
            $("h").firstElementChild.textContent = "Bloccata: giocatore titolato";
            return;
        }
        host.style.display = enabled && !blocked ? "" : "none";
        if (!enabled || blocked) return;
        refreshModes();
        if (!current) { $("ev").textContent = "–"; $("bd").innerHTML = '<div class="sec">In attesa della scacchiera…</div>'; return; }
        const t = current.turn, b = current.lines[0], cpW = whiteCp(b, t), me = myColor(), op = me === "w" ? "b" : "w";
        $("ev").textContent = fmtEval(b, t);
        const w = b.mate != null ? (cpW > 0 ? 100 : 0) : 100 / (1 + Math.pow(10, -cpW / 400));
        $("bar").style.width = w.toFixed(1) + "%";
        const sqs = (l) => { const [x, y] = dispSquares(l.move, current.grid); return `${x} → ${y}${l.move.length > 4 ? "=" + l.move[4].toUpperCase() : ""}`; };

        if (mode === "puzzle") {
            $("bd").innerHTML = t !== me
                ? '<div class="sec">Problema</div><div class="ls">Attendi la risposta dell\'avversario…</div>'
                : `<div class="sec">Soluzione · prof. ${b.depth}</div><div class="big">${sqs(b)}</div><div class="ls">Valutazione ${fmtEval(b, t)}${b.mate != null ? " · matto forzato" : ""}</div>`;
            return;
        }

        const stat = (k) => stats[k];
        const acpl = (k) => (stat(k).n ? (stat(k).cpl / stat(k).n).toFixed(1) : "–");
        const accOf = (k) => { const x = stat(k); return x.n ? (x.acc / x.n + x.n / x.inv) / 2 : null; };
        const accBox = (lbl, k) => {
            const q = accOf(k), col = q == null ? "#8b97a5" : q >= 90 ? "#2ecc71" : q >= 75 ? "#8bd17c" : q >= 60 ? "#f1c40f" : q >= 40 ? "#f08a3c" : "#ee5252";
            return `<div><small>${lbl}</small><b style="color:${col}">${q == null ? "–" : q.toFixed(1) + "%"}</b></div>`;
        };
        const v = verdict[me];
        const last = v ? (() => { const [lbl, col] = classify(v.cpl); return `<div class="ls">Tua ultima mossa: <b style="color:${col}">${lbl}</b> · −${v.cpl} cp</div>`; })() : "";
        $("bd").innerHTML =
            `<div class="sec">Mosse migliori · prof. ${b.depth}</div>` +
            current.lines.slice(0, 3).map((l, i) => `<div class="mv"><b style="background:${COLORS[i]}"></b><span>${sqs(l)}</span><span>${fmtEval(l, t)}</span><em>${i === 0 ? "migl." : "−" + Math.max(0, toCp(b) - toCp(l)) + " cp"}</em></div>`).join("") +
            `<div class="sec">Precisione partita</div><div class="acc">${accBox("Tu", me)}${accBox("Avv.", op)}</div><table style="margin-top:8px"><tr><th></th><th>Tu</th><th>Avv.</th></tr>` +
            `<tr><td>ACPL</td><td>${acpl(me)}</td><td>${acpl(op)}</td></tr>` +
            `<tr><td>Top-1</td><td>${pct(stat(me).top1, stat(me).n)}</td><td>${pct(stat(op).top1, stat(op).n)}</td></tr>` +
            `<tr><td>Top-3</td><td>${pct(stat(me).top3, stat(me).n)}</td><td>${pct(stat(op).top3, stat(op).n)}</td></tr>` +
            `<tr><td>Mosse</td><td>${stat(me).n}</td><td>${stat(op).n}</td></tr></table>` + last;
    }

    // ---------- Ciclo di aggiornamento ----------
    function onResult(m) {
        if (m.move) return onMoveEval(m);
        if (!enabled || blocked || !lastInfo || m.fen !== lastInfo.fen || !m.result.length) return;
        awaiting = null;
        const info = lastInfo, key = info.prevFen + ">" + info.fen;
        if (MODES[mode].stats && prev && info.prevFen === prev.fen && prev.turn !== info.turn && info.move && !done.has(key)) {
            done.add(key); scoreMove(prev, info.move, m.result);
        }
        prev = current = { fen: info.fen, turn: info.turn, lines: m.result, grid: info.grid };
        draw(); renderHud();
    }

    let scheduled = false;
    function update() {
        scheduled = false;
        if (!checkScope()) return;
        const board = getBoard(); if (!board || !enabled) return;
        const info = readBoard(board);
        const key = info.placement + " " + info.turn;
        if (lastInfo && key === lastInfo.key) return;
        info.key = key;
        info.prevFen = lastInfo ? lastInfo.fen : null;
        marks.clear();
        if (!info.move && isInitialSetup(info.grid)) { // nuova partita
            stats = fresh(); verdict = { w: null, b: null }; prev = current = null; done.clear(); info.prevFen = null;
            rights = { K: true, Q: true, k: true, q: true }; home = null;
        }
        const h = getHome(info.grid);
        updateRights(info.grid, h); // aggiornato a ogni posizione vista, anche se l'analisi viene saltata
        info.fen = buildFen(info, h);
        lastInfo = info;
        request(info.fen);
    }
    const schedule = () => { if (!scheduled) { scheduled = true; requestAnimationFrame(update); } };
    new MutationObserver(schedule).observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ["class"] });

    // ---------- Frecce disegnate dall'utente (trascinando col tasto destro) ----------
    function squareAt(e) {
        const board = getBoard(); if (!board) return null;
        const r = board.getBoundingClientRect();
        if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) return null;
        const col = Math.min(7, Math.floor(((e.clientX - r.left) / r.width) * 8));
        const row = Math.min(7, Math.floor(((e.clientY - r.top) / r.height) * 8));
        const flipped = board.classList.contains("flipped");
        return { f: flipped ? 7 - col : col, r: flipped ? row : 7 - row };
    }
    function toggleMark(a, b) {
        if (!enabled || blocked || !current || !lastInfo || current.fen !== lastInfo.fen) return;
        const uci = engineMove(a, b, lastInfo.grid), key = uci.slice(0, 4);
        if (marks.has(key)) { marks.delete(key); draw(); return; }
        const known = current.lines.find((l) => l.move.slice(0, 4) === key);
        marks.set(key, { uci, line: known || null, pending: !known });
        if (!known) requestMove(current.fen, uci);
        draw();
    }
    function onMoveEval(m) {
        if (!lastInfo || m.fen !== lastInfo.fen) return;
        const mk = marks.get(m.move.slice(0, 4)); if (!mk) return;
        mk.pending = false; mk.line = m.result[0] || false; draw();
    }
    window.addEventListener("mousedown", (e) => {
        if (e.button === 2) rightStart = squareAt(e);
        else if (e.button === 0 && marks.size && squareAt(e)) { marks.clear(); draw(); }
    }, true);
    window.addEventListener("mouseup", (e) => {
        if (e.button !== 2 || !rightStart) return;
        const a = rightStart, b = squareAt(e); rightStart = null;
        if (b && !(a.f === b.f && a.r === b.r)) toggleMark(a, b);
    }, true);

    // Attiva/disattiva frecce e pannello: pulsante flottante ♞ (oppure Alt+A con tastiera)
    function toggleEnabled() {
        if (blocked || titleLock) return;
        enabled = !enabled;
        if (!enabled) { if (svg) svg.innerHTML = ""; renderHud(); }
        else { lastInfo = null; renderHud(); schedule(); }
    }
    document.addEventListener("keydown", (e) => { if (e.altKey && e.key.toLowerCase() === "a") toggleEnabled(); });

    // Frecce col dito: attiva "✎ Disegna frecce", poi trascina da una casella all'altra
    let drawMode = false;
    $("tdraw").addEventListener("click", () => {
        drawMode = !drawMode; rightStart = null;
        $("tdraw").classList.toggle("on", drawMode);
        $("tdraw").textContent = drawMode ? "✎ Disegno: ON" : "✎ Disegna frecce";
    });
    const tpt = (e) => { const t = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]); return t ? { clientX: t.clientX, clientY: t.clientY } : null; };
    window.addEventListener("touchstart", (e) => {
        if (!drawMode || blocked) return;
        const p = tpt(e), s = p && squareAt(p); if (!s) return;
        rightStart = s; e.preventDefault(); e.stopPropagation();
    }, { capture: true, passive: false });
    window.addEventListener("touchmove", (e) => { if (drawMode && rightStart) e.preventDefault(); }, { capture: true, passive: false });
    window.addEventListener("touchend", (e) => {
        if (!drawMode || !rightStart) return;
        const a = rightStart, p = tpt(e), b = p && squareAt(p); rightStart = null;
        if (b && !(a.f === b.f && a.r === b.r)) toggleMark(a, b);
        else if (marks.size) { marks.clear(); draw(); }
        e.preventDefault(); e.stopPropagation();
    }, { capture: true, passive: false });

    setInterval(checkScope, 500);
    addEventListener("popstate", checkScope);

    // ---------- Avvio: modalità salvata (sui problemi parte "Problemi") ----------
    const onPuzzles = location.pathname.startsWith("/puzzles");
    let savedMode = "normal";
    try { const v = localStorage.getItem("csa_mode"); if (MODES[v]) savedMode = v; } catch (_) { }
    applyMode(onPuzzles ? "puzzle" : savedMode === "puzzle" ? "normal" : savedMode, false);
    refreshModes(); renderHud();
})();