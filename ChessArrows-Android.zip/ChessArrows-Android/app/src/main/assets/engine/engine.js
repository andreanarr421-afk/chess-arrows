const EVAL_MS = 250; // valutazione di una singola mossa (frecce disegnate a mano)

let cfg = { multipv: 3, movetime: 120, chess960: false };
let booted = false, ready = false, busy = false, current = null, pendingPos = null, pendingConfig = null, lines = {};
const evalQueue = [];

let worker = null;
const outbox = [];
const send = (c) => { if (worker) worker.postMessage(c); else outbox.push(c); };
send("uci");

// Il motore gira in un Worker creato da Blob: nessuna dipendenza dalle richieste dei worker del WebView.
async function startWorker() {
  const [js, wasm] = await Promise.all([
    fetch("stockfish-19-lite-single.js").then((r) => r.text()),
    fetch("stockfish-19-lite-single.wasm").then((r) => r.arrayBuffer()),
  ]);
  const wasmUrl = URL.createObjectURL(new Blob([wasm], { type: "application/wasm" }));
  const jsUrl = URL.createObjectURL(new Blob([js], { type: "text/javascript" }));
  worker = new Worker(jsUrl + "#" + encodeURIComponent(wasmUrl));
  worker.onmessage = onWorkerMessage;
  while (outbox.length) worker.postMessage(outbox.shift());
}

function applyConfig(c) {
  cfg = c; ready = false;
  send("setoption name MultiPV value " + c.multipv);
  send("setoption name UCI_Chess960 value " + (c.chess960 ? "true" : "false"));
  send("isready");
}

function next() {
  if (!booted || busy) return;
  if (pendingConfig) { const c = pendingConfig; pendingConfig = null; applyConfig(c); return; }
  if (!ready) return;
  let req = evalQueue.shift();
  if (!req && pendingPos) { req = pendingPos; pendingPos = null; }
  if (req) run(req);
}

function run(req) {
  current = req; busy = true; lines = {};
  send("position fen " + req.fen);
  send(req.move ? `go movetime ${EVAL_MS} searchmoves ${req.move}` : `go movetime ${cfg.movetime}`);
}

const onWorkerMessage = (e) => {
  const line = typeof e.data === "string" ? e.data : "";
  if (line === "uciok") {
    booted = true;
    const c = pendingConfig || cfg; pendingConfig = null;
    applyConfig(c);
  } else if (line === "readyok") {
    ready = true; next();
  } else if (line.startsWith("info") && line.includes(" pv ")) {
    const mpv = +(/multipv (\d+)/.exec(line) || [0, 1])[1];
    const depth = +(/depth (\d+)/.exec(line) || [0, 0])[1];
    const cp = /score cp (-?\d+)/.exec(line);
    const mate = /score mate (-?\d+)/.exec(line);
    const pv = line.split(" pv ")[1].trim().split(" ");
    lines[mpv] = { move: pv[0], depth, cp: cp ? +cp[1] : null, mate: mate ? +mate[1] : null };
  } else if (line.startsWith("bestmove")) {
    busy = false;
    const req = current; current = null;
    const stale = pendingConfig || (!req.move && pendingPos); // impostazioni cambiate o posizione più recente in attesa
    if (!stale) {
      const result = Object.keys(lines).sort((a, b) => a - b).map((k) => lines[k]);
      try { req.port.postMessage({ fen: req.fen, move: req.move, result }); } catch (_) {}
    }
    next();
  }
};

const port = { postMessage: (m) => Android.toPage(JSON.stringify(m)) };
window.__fromApp = (str) => {
  let msg; try { msg = JSON.parse(str); } catch (_) { return; }
  if (msg.type === "config") {
    pendingConfig = { multipv: msg.multipv, movetime: msg.movetime, chess960: !!msg.chess960 };
    pendingPos = null; evalQueue.length = 0;
    if (busy) send("stop");
    next();
    return;
  }
  const req = { fen: msg.fen, move: msg.move || null, port };
  if (req.move) evalQueue.push(req);
  else {
    pendingPos = req;
    if (busy && current && !current.move) send("stop");
  }
  next();
};
startWorker().catch((err) => console.error("engine start failed", err));
