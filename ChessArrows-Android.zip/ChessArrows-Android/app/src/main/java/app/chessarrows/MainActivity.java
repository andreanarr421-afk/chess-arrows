package app.chessarrows;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Chess Arrows (studio) per Android.
 *
 * - WebView "web": mostra chess.com e riceve lo script csa.js (la tua estensione adattata).
 * - WebView "engine": nascosto, pagina locale che esegue Stockfish 19 (WASM) in un Worker.
 * - Ponte: la pagina chiede analisi a Java, Java le gira al motore e rimanda il risultato alla pagina.
 *
 * AMBITO: il motore risponde SOLO su bot (/play/computer), analisi (/analysis) e problemi (/puzzles).
 * Il controllo e' fatto qui in Java sull'URL reale del WebView, quindi vale qualunque cosa faccia la pagina.
 */
public class MainActivity extends Activity {

    private static final String START_URL = "https://www.chess.com/play/computer";
    private static final String ENGINE_HOST = "engine.chessarrows.local";
    private static final String ENGINE_BASE = "https://" + ENGINE_HOST + "/";

    // Percorsi in cui l'analisi e' permessa. Qualsiasi altro percorso (partite online, /game, ecc.) e' escluso.
    private static final String[] ALLOWED_PATHS = {"/play/computer", "/analysis", "/puzzles"};

    // User agent "sito desktop": chess.com serve la pagina completa con la scacchiera.
    // Per provare il layout mobile di chess.com metti questa costante a null.
    private static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private static final Pattern FEN = Pattern.compile(
            "^[1-8pnbrqkPNBRQK/]{15,100} [wb] (-|[KQkqA-Ha-h]{1,4}) (-|[a-h][36]) \\d{1,3} \\d{1,4}$");
    private static final Pattern MOVE = Pattern.compile("^[a-h][1-8][a-h][1-8][qrbn]?$");

    private WebView web;
    private WebView engine;
    private String csaScript = "";
    private boolean engineLoaded = false;
    private final List<String> queue = new ArrayList<>();

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        csaScript = readAsset("csa.js");

        FrameLayout root = new FrameLayout(this);
        web = new WebView(this);
        engine = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(engine, new FrameLayout.LayoutParams(2, 2));
        engine.setAlpha(0f);
        setContentView(root);

        setupEngine();
        setupWeb();

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START_URL);
        }
    }

    // ---------------------------------------------------------------- motore

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupEngine() {
        WebSettings s = engine.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        engine.addJavascriptInterface(new EngineBridge(), "Android");
        engine.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return serveEngineAsset(request.getUrl());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                engineLoaded = true;
                flushQueue();
            }
        });
        engine.loadUrl(ENGINE_BASE + "engine.html");
    }

    private WebResourceResponse serveEngineAsset(Uri u) {
        if (u == null || !ENGINE_HOST.equals(u.getHost())) return reply(403, "Forbidden");
        String p = u.getPath();
        if (p == null || p.equals("/") || p.isEmpty()) p = "/engine.html";
        if (p.contains("..")) return reply(403, "Forbidden");
        String name = p.substring(1);
        String mime = name.endsWith(".html") ? "text/html"
                : name.endsWith(".js") ? "text/javascript"
                : name.endsWith(".wasm") ? "application/wasm"
                : "application/octet-stream";
        try {
            InputStream in = getAssets().open("engine/" + name);
            return new WebResourceResponse(mime, "utf-8", in);
        } catch (IOException e) {
            return reply(404, "Not Found");
        }
    }

    private WebResourceResponse reply(int code, String text) {
        return new WebResourceResponse("text/plain", "utf-8", code, text, null,
                new ByteArrayInputStream(new byte[0]));
    }

    private void sendToEngine(String safeJson) {
        if (!engineLoaded) {
            queue.add(safeJson);
            return;
        }
        engine.evaluateJavascript("window.__fromApp(" + JSONObject.quote(safeJson) + ")", null);
    }

    private void flushQueue() {
        for (String m : queue) {
            engine.evaluateJavascript("window.__fromApp(" + JSONObject.quote(m) + ")", null);
        }
        queue.clear();
    }

    // ---------------------------------------------------------------- chess.com

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        if (DESKTOP_UA != null) s.setUserAgentString(DESKTOP_UA);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new PageBridge(), "CSAEngine");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (isChessCom(u)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && isChessCom(Uri.parse(url))) {
                    view.evaluateJavascript(csaScript, null);
                }
            }
        });
    }

    private static boolean isChessCom(Uri u) {
        if (u == null || !"https".equals(u.getScheme())) return false;
        String h = u.getHost();
        return h != null && (h.equals("chess.com") || h.endsWith(".chess.com"));
    }

    /** Barriera di ambito lato Java: guarda l'URL reale del WebView (anche dopo navigazioni interne al sito). */
    private boolean scopeAllowed() {
        String url = web.getUrl();
        if (url == null) return false;
        Uri u = Uri.parse(url);
        if (!isChessCom(u)) return false;
        String p = u.getPath();
        if (p == null) return false;
        for (String a : ALLOWED_PATHS) {
            if (p.equals(a) || p.startsWith(a + "/")) return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- ponti

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Accetta solo i due tipi di messaggio previsti, ricostruiti da zero: config oppure fen (+ mossa). */
    private static String sanitize(String json) {
        if (json == null || json.length() > 400) return null;
        try {
            JSONObject o = new JSONObject(json);
            JSONObject out = new JSONObject();
            if ("config".equals(o.optString("type"))) {
                out.put("type", "config");
                out.put("multipv", clamp(o.optInt("multipv", 3), 1, 5));
                out.put("movetime", clamp(o.optInt("movetime", 120), 20, 3000));
                out.put("chess960", o.optBoolean("chess960", false));
                return out.toString();
            }
            String fen = o.optString("fen", "");
            if (!FEN.matcher(fen).matches()) return null;
            out.put("fen", fen);
            if (o.has("move") && !o.isNull("move")) {
                String mv = o.optString("move", "");
                if (!MOVE.matcher(mv).matches()) return null;
                out.put("move", mv);
            }
            return out.toString();
        } catch (JSONException e) {
            return null;
        }
    }

    /** Pagina chess.com -> motore. */
    private class PageBridge {
        @JavascriptInterface
        public void toEngine(String json) {
            final String safe = sanitize(json);
            if (safe == null) return;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!scopeAllowed()) return; // fuori ambito: nessuna analisi
                    sendToEngine(safe);
                }
            });
        }
    }

    /** Motore -> pagina chess.com. */
    private class EngineBridge {
        @JavascriptInterface
        public void toPage(String json) {
            String tmp;
            try {
                tmp = new JSONObject(json).toString();
            } catch (JSONException e) {
                return;
            }
            final String safe = tmp;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    web.evaluateJavascript("window.__csaResult&&window.__csaResult(" + safe + ")", null);
                }
            });
        }
    }

    // ---------------------------------------------------------------- ciclo di vita

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        engine.onResume();
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        engine.destroy();
        super.onDestroy();
    }
}
